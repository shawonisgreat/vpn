package app.witwork.vpn.presentation.servers

import app.witwork.vpn.common.base.BaseView
import app.witwork.vpn.domain.model.Server

interface ServerListView : BaseView {
    fun onGetServersSuccess(servers: List<Server>?)
}