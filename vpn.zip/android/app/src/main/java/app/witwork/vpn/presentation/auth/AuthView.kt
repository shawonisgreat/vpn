package app.witwork.vpn.presentation.auth

import app.witwork.vpn.common.base.BaseView
import app.witwork.vpn.domain.model.User

interface AuthView : BaseView {
    fun onSignInSuccess(user: User?)
    fun onSignUpSuccess(user: User)
}