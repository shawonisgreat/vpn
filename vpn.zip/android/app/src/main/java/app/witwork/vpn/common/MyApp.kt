package app.witwork.vpn.common;

import android.app.Application
import app.witwork.vpn.BuildConfig
import app.witwork.vpn.common.di.component.AppComponent
import app.witwork.vpn.common.di.component.DaggerAppComponent
import app.witwork.vpn.common.utils.Feature
import com.google.android.gms.ads.MobileAds
import com.onesignal.OneSignal
import timber.log.Timber

class MyApp : Application() {
    companion object {
        lateinit var self: MyApp
            private set
    }

    val appComponent: AppComponent by lazy {
        return@lazy DaggerAppComponent.builder()
            .application(this)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        self = this
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        if (Feature.FEATURE_ALLOW_ADMOB) {
            MobileAds.initialize(this)
        }

        initOneSignal()
    }

    private fun initOneSignal() {
        // Logging set to help debug issues, remove before releasing your app.
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)

        // OneSignal Initialization
        OneSignal.startInit(this)
            .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
            .unsubscribeWhenNotificationsAreDisabled(true)
            .init()
    }
}