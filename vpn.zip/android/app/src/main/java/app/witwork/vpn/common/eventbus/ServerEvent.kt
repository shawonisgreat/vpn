package app.witwork.vpn.common.eventbus

import app.witwork.vpn.domain.model.Server

data class ServerEvent private constructor(val value: Server?, val change: Boolean) {
    companion object {
        fun init(value: Server?, change: Boolean) = ServerEvent(value, change)
    }
}