package app.witwork.vpn.common.eventbus

data class ChangeTabEvent(val tabIndex: Int){
    companion object{
        val premium = ChangeTabEvent(1)
    }
}