package app.witwork.vpn.presentation.home

import app.witwork.vpn.common.base.BaseView

interface HomeView : BaseView {
    fun onConnected()
    fun onDisconnected()
    fun onUpdateConnectionStatus(upload: String? = null, download: String? = null)
}