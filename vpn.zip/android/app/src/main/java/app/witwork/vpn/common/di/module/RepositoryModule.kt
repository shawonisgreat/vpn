package app.witwork.vpn.common.di.module

import app.witwork.vpn.data.repos.BillingRepositoryImpl
import app.witwork.vpn.data.repos.ConfigRepositoryImpl
import app.witwork.vpn.data.repos.ServerRepositoryImpl
import app.witwork.vpn.data.repos.UserRepositoryImpl
import app.witwork.vpn.domain.repos.BillingRepository
import app.witwork.vpn.domain.repos.ConfigRepository
import app.witwork.vpn.domain.repos.ServerRepository
import app.witwork.vpn.domain.repos.UserRepository
import dagger.Binds
import dagger.Module

@Module
abstract class RepositoryModule {
    @Binds
    abstract fun bindBillingRepository(billingRepositoryImpl: BillingRepositoryImpl): BillingRepository

    @Binds
    abstract fun bindUserRepository(userRepositoryImpl: UserRepositoryImpl): UserRepository

    @Binds
    abstract fun bindServerRepository(serverRepositoryImpl: ServerRepositoryImpl): ServerRepository

    @Binds
    abstract fun bindConfigRepository(configRepositoryImpl: ConfigRepositoryImpl): ConfigRepository
}