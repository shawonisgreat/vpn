package app.witwork.vpn.common.di.component

import android.app.Application
import app.witwork.vpn.common.di.module.AppModule
import app.witwork.vpn.common.di.module.RepositoryModule
import app.witwork.vpn.presentation.auth.AuthFragment
import app.witwork.vpn.presentation.auth.ForgotPasswordFragment
import app.witwork.vpn.presentation.home.HomeFragment
import app.witwork.vpn.presentation.main.MainFragment
import app.witwork.vpn.presentation.password.ChangePasswordFragment
import app.witwork.vpn.presentation.other.policy.PrivatePolicyFragment
import app.witwork.vpn.presentation.premium.PremiumFragment
import app.witwork.vpn.presentation.profile.EditProfileFragment
import app.witwork.vpn.presentation.servers.ServerListFragment
import app.witwork.vpn.presentation.servers.tab.TabFragment
import app.witwork.vpn.presentation.splash.SplashFragment
import dagger.BindsInstance
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AppModule::class,
        RepositoryModule::class
    ]
)
interface AppComponent {
    fun inject(splashFragment: SplashFragment)
    fun inject(editProfileFragment: EditProfileFragment)
    fun inject(mainFragment: MainFragment)
    fun inject(premiumFragment: PremiumFragment)
    fun inject(homeFragment: HomeFragment)
    fun inject(serverListFragment: ServerListFragment)
    fun inject(tabFragment: TabFragment)
    fun inject(authFragment: AuthFragment)
    fun inject(forgotPasswordFragment: ForgotPasswordFragment)
    fun inject(privatePolicyFragment: PrivatePolicyFragment)
    fun inject(changePasswordFragment: ChangePasswordFragment)

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: Application): Builder

        fun build(): AppComponent
    }
}