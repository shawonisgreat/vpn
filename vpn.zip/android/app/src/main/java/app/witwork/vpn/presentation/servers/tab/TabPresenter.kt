package app.witwork.vpn.presentation.servers.tab

import app.witwork.vpn.common.base.BasePresenter
import javax.inject.Inject

class TabPresenter @Inject constructor() : BasePresenter<TabView>() {

}