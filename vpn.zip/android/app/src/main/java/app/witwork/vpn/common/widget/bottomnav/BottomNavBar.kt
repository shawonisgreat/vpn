package app.witwork.vpn.common.widget.bottomnav

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import app.witwork.vpn.R

class BottomNavBar(context: Context?, attrs: AttributeSet?) : LinearLayout(context, attrs), View.OnClickListener {
    companion object {
        const val TAB_HOME = 0
        const val TAB_PREMIUM = 1
        const val TAB_PROFILE = 2
    }

    private lateinit var tabHome: BottomNavItem
    private lateinit var tabPremium: BottomNavItem
    private lateinit var tabProfile: BottomNavItem

    var listener: OnTabChangedListener? = null

    var currentTabSelected = -1
        set(value) {
            val changed = field != value
            if (changed) {
                if (toggle(value)) {
                    field = value
                }
            } else {
                listener?.reSelected(field)
            }
        }

    override fun onFinishInflate() {
        super.onFinishInflate()
        tabHome = findViewById(R.id.tab_home)
        tabPremium = findViewById(R.id.tab_premium)
        tabProfile = findViewById(R.id.tab_profile)

        tabHome.setOnClickListener(this)
        tabPremium.setOnClickListener(this)
        tabProfile.setOnClickListener(this)

        this.currentTabSelected = TAB_HOME
    }

    override fun onClick(p0: View?) {
        this.currentTabSelected = when (p0?.id) {
            R.id.tab_home -> {
                TAB_HOME
            }
            R.id.tab_premium -> {
                TAB_PREMIUM
            }
            else -> {
                TAB_PROFILE
            }
        }
    }

    private fun toggle(tabSelected: Int): Boolean {
        val change = listener?.changed(tabSelected)

        if (change == false) {
            return false
        }
        tabHome.isSelected = tabSelected == TAB_HOME
        tabPremium.isSelected = tabSelected == TAB_PREMIUM
        tabProfile.isSelected = tabSelected == TAB_PROFILE
        return true
    }

    interface OnTabChangedListener {
        fun changed(tabIndex: Int): Boolean
        fun reSelected(tabIndex: Int)
    }

}