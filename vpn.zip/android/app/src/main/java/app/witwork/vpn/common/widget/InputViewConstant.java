package app.witwork.vpn.common.widget;

import app.witwork.vpn.R;

class InputViewConstant {
    public static int[] STATE_ERROR = new int[]{R.attr.state_error};
}
