package app.witwork.vpn.presentation.other.policy

import app.witwork.vpn.common.base.BaseView

interface PrivatePolicyView : BaseView {
}