package app.witwork.vpn.presentation.splash;

import app.witwork.vpn.common.base.BaseActivity
import app.witwork.vpn.common.base.BaseFragment
import com.steve.utilities.core.connectivity.base.ConnectivityProvider

class SplashActivity : BaseActivity() {

    override fun injectFragment(): BaseFragment<*, *> {
        return SplashFragment()
    }

    override fun onStateChange(state: ConnectivityProvider.NetworkState) {
        //nothing
    }
}
