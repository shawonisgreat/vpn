package app.witwork.vpn.presentation.auth

import app.witwork.vpn.common.base.BasePresenter
import app.witwork.vpn.common.utils.completableTransformer
import app.witwork.vpn.common.utils.observableTransformer
import app.witwork.vpn.domain.model.User
import app.witwork.vpn.domain.repos.UserRepository
import com.steve.utilities.core.extensions.addToCompositeDisposable
import timber.log.Timber
import javax.inject.Inject

class AuthPresenter @Inject constructor() : BasePresenter<AuthView>() {
    @Inject
    lateinit var userRepository: UserRepository

    fun signIn(email: String, password: String) {
        userRepository.signIn(email, password)
            .compose(observableTransformer(view))
            .subscribe({
                view?.onSignInSuccess(it)
            }, this::handleError)
            .addToCompositeDisposable(disposable)
    }

    fun signUp(email: String, password: String) {
        userRepository.signUp(email, password)
            .compose(completableTransformer(view))
            .subscribe({
                Timber.e("sigunUp successfully")
                val user = User(email, password)
                view?.onSignUpSuccess(user)
            }, this::handleError)
            .addToCompositeDisposable(disposable)
    }

}