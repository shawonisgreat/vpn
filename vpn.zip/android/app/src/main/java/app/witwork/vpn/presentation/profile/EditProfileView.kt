package app.witwork.vpn.presentation.profile

import app.witwork.vpn.common.base.BaseView
import app.witwork.vpn.domain.model.User

interface EditProfileView : BaseView {
    fun onUpgradeSuccess()
    fun onLogoutSuccess()
    fun onGetCurrentUserSuccess(user: User?)
}